# Example sd_jpg

Take pictures with intervals of 20 seconds and store then to SD card.

## Instructions

In order to run this example, format any MicroSD card with FAT and insert it to the board.

All camera pins are configured by default accordingly to [this A.I. Thinker document](../../assets/ESP32-CAM_Product_Specification.pdf) and you can check then inside [Kconfig.projbuild](./main/Kconfig.projbuild).
